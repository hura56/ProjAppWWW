<?php
$plik_require_once = 'tekst z pliku z require_once'
?>