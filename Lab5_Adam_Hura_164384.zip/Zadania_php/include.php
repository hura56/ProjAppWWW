<?php
$plik_include = '123'
?>