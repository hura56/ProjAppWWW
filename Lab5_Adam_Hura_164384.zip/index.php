<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="Content-type" content="text/html; charset=UTF-8" />
    <meta http-equiv="Content-Language" content="pl" />
    <meta name="Author" content="Adam Hura" />
    <title>MMA moją pasją</title>
    <link rel="stylesheet" href="css/styles.css" />
    <script src="js/kolorujtlo.js" type="text/javascript"></script>
    <script src="js/timedate.js" type="text/javascript"></script>
    <script src="js/kontrast.js" type="text/javascript"></script>
</head>

<body onload="startclock()">
    <h1>MMA</h1>
    <div class="container">
        <button onclick="kontrast()">Kontrast</button>
    </div>
    <div id="zegarek"></div>
        <div id="data"></div>
    <table>
    <tr>
            <td></td>
            <td class="ref">
                <a href="index.php"><b>Strona Główna</b></a>
                <a href="?idp=podstrona4"><b>Największe organizacje|</b></a>
                <a href="?idp=podstrona5"><b>Polacy w Swiatowym MMA|</b></a>
                <a href="?idp=podstrona2"><b>Historia|</b></a>
                <a href="?idp=podstrona1"><b>Ciekawostki|</b></a>
                <a href="?idp=podstrona3"><b>Kontakt|</b></a>
                <a href="?idp=podstrona6"><b>test_lab3|</b></a>
                <a href="?idp=podstrona7"><b>Filmy</b></a>
            </td>
            <td></td>
        </tr>
<tr>
    <td></td>
    <td class="main">
    <?php
    error_reporting(E_ALL ^ E_NOTICE ^ E_WARNING);
    if($_GET['idp'] == '' && file_exists('html/strona.html'))$strona = 'html/strona.html';
    if($_GET['idp'] == 'podstrona1' && file_exists('html/ciekawostki.html'))$strona = 'html/ciekawostki.html';
    if($_GET['idp'] == 'podstrona2' && file_exists('html/historia.html'))$strona = 'html/historia.html';
    if($_GET['idp'] == 'podstrona3' && file_exists('html/kontakt.html'))$strona = 'html/kontakt.html';
    if($_GET['idp'] == 'podstrona4' && file_exists('html/org.html'))$strona = 'html/org.html';
    if($_GET['idp'] == 'podstrona5' && file_exists('html/polacy.html'))$strona = 'html/polacy.html';
    if($_GET['idp'] == 'podstrona6' && file_exists('html/test_lab3.html')) $strona = 'html/test_lab3.html';
    if($_GET['idp'] == 'podstrona7' && file_exists('html/filmy.html')) $strona = 'html/filmy.html';
    include($strona);
?>
    </td>
</tr>
<td></td>
    </table>

    <?php
    $nr_indeksu = '164384';
    $nrGrupy = '2';
    echo '<b><span style="color: rgb(184, 18, 18);">Autor: Adam Hura ' . $nr_indeksu . ' grupa ' . $nrGrupy . ' <br /><br /></b>';
    ?>
</body>

</html>
