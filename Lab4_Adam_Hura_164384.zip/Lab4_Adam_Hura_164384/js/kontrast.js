function kontrast() {
    var tdElements = document.getElementsByClassName('main');
    var button = document.querySelector('button');

    for (var i = 0; i < tdElements.length; i++) {
        if (tdElements[i].style.backgroundColor === 'white' || tdElements[i].style.backgroundColor === '') {
            tdElements[i].style.backgroundColor = 'black';
            tdElements[i].style.color = 'white';
            button.style.backgroundColor = 'white';
            button.style.color = 'black';
        } else {
            tdElements[i].style.backgroundColor = 'white';
            tdElements[i].style.color = 'black';
            button.style.backgroundColor = 'black';
            button.style.color = 'white';
        }
    }
}